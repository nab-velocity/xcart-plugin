<?php

class VelocityConfig 
{
	public static $baseurl_test = 'https://api.cert.nabcommerce.com/REST/2.0.18/';  // for test transaction
	public static $baseurl_live = 'https://api.nabcommerce.com/REST/2.0.18/'; // for live transaction
}
